# import libraries
from bs4 import BeautifulSoup
from selenium import webdriver
import pandas as pd
import datetime, re, time, itertools, smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib


data=[]

page ='https://www.fanatics.com/nba/chicago-bulls/ayo-dosunmu-chicago-bulls-fanatics-branded-2021-nba-draft-second-round-pick-fast-break-replica-jersey-red-icon-edition/o-3592+t-81259589+p-82711491330+z-9-1806849756' 
driver = webdriver.Chrome(executable_path=r"/Users/meghanmokate/Desktop/chromedriver")
driver.get(page)  
time.sleep(15)
soup = BeautifulSoup(driver.page_source, 'html.parser')

for available in driver.find_elements_by_css_selector('size-selector-button available'):
        available_data = available[0].text
        print(available_data)

for unavailable in driver.find_elements_by_css_selector('size-selector-button unavailable'):
        unavailable_data = unavailable[0].text
        print(unavailable_data)




# my_table = soup.find(class_=['drop-down-selected'])
my_table = driver.find_elements_by_class_name("size-selector-button available")

#"size-selector-button unavailable"
#"size-selector-button available"
#aria-label="Size L"
for name in driver.find_elements_by_class_name('listingDescription'):
        name_data = name.find_elements_by_tag_name('a') 
if my_table.find_elements_by_class_name("size-selector-button available"):            
    #Email info
    sender = 'megfindstickets@gmail.com'
    password = 'TicketFinder0219'
    port = 465 # 465 (GMAIL), 587, or 25
    receive = 'meghanmokate@gmail.com'
           
    #Email content
    msg = MIMEMultipart()
    msg['From'] = sender
    msg['To'] = receive
    msg['Subject'] = 'Great deal on tickets found!'

    body = 'Go here to see the great deal:' + re.sub('https://www.', '', page)
    msg.attach(MIMEText(body,'plain'))
    text = msg.as_string()

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
        server.ehlo()
        server.login(sender, password)
        server.sendmail(sender, receive, text)

        print('Email Sent')

    else:
        if my_table.find_elements_by_class_name("size-selector-button available"):


            None                 
except:
    data.append('No flights found')

driver.quit()

# BELOW LEARN HOW TO RUN CONTINUOUSLY
# https://towardsdatascience.com/automate-your-python-scripts-with-task-scheduler-661d0a40b279
# https://towardsdatascience.com/how-to-find-cheap-flights-in-80-lines-of-code-ba4f492587db

