

library(tidyverse)

text = read_csv('properties_.csv') %>%
  filter(!is.na(Text))

count
update_1 = data.frame()

update_1$text <- str_split(text$Text, pattern = " ", n = Inf, simplify = FALSE)
