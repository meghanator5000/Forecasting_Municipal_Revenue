import json
import datetime
import pandas as pd
import numpy as np
from selenium import webdriver
from selenium.common.exceptions import (NoSuchElementException,StaleElementReferenceException,TimeoutException)
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
import re
from pandas import DataFrame

# #generate details json
# TEXT_JSON_FILE = "text_output.json"

# with open('links_shop.json') as json_file:
#     links_list = json.load(json_file)

# def new_driver():
#     driver = webdriver.Chrome(executable_path=r"/Users/meghanmokate/Desktop/chromedriver")
#     driver.maximize_window()  # maximize so all elements are clickable
#     return driver


# def get_attribute(driver, links_index): 
#     texts = []
#     link = links_list[links_index]["Link"] 
#     for row in driver.find_elements_by_xpath('/html'):
#         text = row.text
#         detail = {
                   
#                     "Text": text
#         }
#         texts.append(detail) # might need to change to extend?
#     return texts

# # execute functions on webpage
# if __name__ == "__main__":
#     texts = [] 
#     driver = new_driver()
#     #driver.get('https://lane201.com/')
#     for i in range(len(links_list)):
#         driver.get(links_list[i]['Link'])
#         for i in range(2):
#             texts_json_file = open(TEXT_JSON_FILE, 'w')
#             json.dump(texts, texts_json_file, indent=4)   
#             texts_json_file.close() 
#             texts.extend(get_attribute(driver, i))
#             if texts is None or len(texts) == 0:
#                 raise FileNotFoundError

#     print("all details processes done")

# # create dataframe and output to file

attribute = pd.read_json (r'/Users/meghanmokate/Desktop/loop_net_scrape/text_output.json')
attribute_df = pd.DataFrame(attribute)



print(attribute_df)

#attribute_split = attribute_df['Text'].str.split('\\',expand=True)

#print(attribute_split)
#attribute_df.to_csv(str('text_from_site' + '.csv'))

